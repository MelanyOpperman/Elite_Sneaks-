<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products</title>
    <link rel="stylesheet" href="style.css">

    <!-- the styling for this screen -->
    <style>
        .ViewProduct_hero {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
            align-items: center;
            background-color: #581830;
            margin-top: -100px;
            height: 130vh;
        }

        .ViewProd_page {
            display: flex;
            align-items: center;
            margin: 20px;
        }

        .ViewProd_page .rightside {
            flex: 1 1 auto;
            margin-left: 20px;
        }

        .ViewProd_page .ViewProductName {
            font-size: 27px;
            color: #fff;
            margin-top: 0; 
            margin-bottom: 10px;         
        }

        .ViewProd_page .ViewProductDescription {
            font-size: 20px;
            color: #fff;
            margin-bottom: 10px;
        }

        .ViewProd_page img.ViewProductImage {
            width: 35em;
            height: auto;
            margin-right: 20px;
        } 

        .ViewProd_page .product-price {
            font-size: 18px;
            font-weight: bold;
            color: #fff;
            margin-bottom: 15px;
        }

        .ViewProd_page .quantityLabel,
        .ViewProd_page .shoeSizeLabel {
            font-size: 18px;
            color: #fff;
            margin-bottom: 5px;
        }

        .ViewProd_page .quantityInput,
        .ViewProd_page .shoeSizeInput{
            width: 60px;
            padding: 10px;
            margin-bottom: 10px;
        }

        .ViewProd_page .btnAddCart {
            display: inline-block;
            padding: 10px 20px;
            background-color: #fff;
            color: #581830;
            font-weight: bold;
            text-decoration: none;
            border-radius: 5px;
            margin-right: 10px;
        }
    </style>
</head>
<body>
    

    <!--For the products-->
    <div class="ViewProduct_hero" >
        <header style="background-color: #581830;">
            <?php
                include 'menu.php';
            ?>
        </header>

        <?php
        //check if the productID is in the URL
        if (isset($_GET['productID'])) {
            $productID = $_GET['productID'];

            //connect to the database
            //the database details were created in the account privileges in Xampp
            //Connecting to the database
            require_once('database_config.php');
        
            //creating the connection to the database
            $connection = mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD,DB_NAME);
            
            //checking if the connection works 
            if (!$connection)
            {
                die("This Connection has Failed!".mysqli_connect_error());
            }

            //fetching the product details (based on productID)
            $displayProduct = $connection->prepare("SELECT productID, productName, productDescription, productImage, productPrice From producttable WHERE productID=?");
            $displayProduct->bind_param("i",$productID);
            $displayProduct->execute();
            $result = $displayProduct->get_result();

            //check to see if the product exists
            if ($result->num_rows>0) {
                $product = $result->fetch_assoc();
                //displaying the products details
                echo '<div class="ViewProd_page">';
                echo '<div class="rightside">';
                echo '<h2 class="ViewProductName">'. $product['productName'] .'</h2>';
                echo '<p class="ViewProductDescription">'. $product['productDescription'] .'</p>';
                echo '<p class="product-price view-products">R'. $product['productPrice'] .'</p>';
                echo '<form method="POST" action="AddToCart.php">';
                echo '<h4 class="quantityLabel">Quantity: </h4>';
                echo '<input type="number" value="1" class="view-products" name="quantity">';
                echo "<input type='hidden' name='productID' value='" . $productID . "'>";
                echo '<h4 class="shoeSizeLabel">Shoe Size: </h4>';
                echo '<input type="text" placeholder="Shoe Size" class="view-products" name="shoeSize">';
                echo '<br>';
                echo '<br>';
                if(isset($_SESSION['customer']) && $_SESSION['customer']==true){
                    echo '<button type="submit" name="addToCart" class="btnAddCart">ADD TO CART</a>';
                }else{
                    echo "<h2 style='color:#ffff;'>Please log into add this item to cart</h2>";
                }
                echo '</form>';
                echo '</div>';
                echo '<img  src="'. $product['productImage'] .'" alt="'. $product['productName'] .'" class="ViewProductImage">';
                echo '</div>';
            } else {
                echo "Product Not Found.";
            }

            //closing the database
            $connection->close();
        } else {
            echo "Product ID not Specified.";
        }
        ?>

    </div>
</body>