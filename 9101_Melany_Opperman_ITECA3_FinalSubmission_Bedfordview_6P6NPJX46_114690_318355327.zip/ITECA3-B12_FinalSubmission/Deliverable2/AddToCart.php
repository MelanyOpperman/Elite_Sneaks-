<?php

    session_start();

    //Connecting to the database
    require_once('database_config.php');
        
    //creating the connection to the database
    $connection = mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD,DB_NAME);

    if(!isset($_SESSION['customerID'])){
        echo "<script>alert('Please log in to continue')</script>";
        header('Refresh: 1; url=login.php');
        exit();
    }

    //check if the productID and quantity are provided as query parameters
    if (isset($_POST['addToCart'])) {
        //Get from form
        $productID =$_POST['productID'];
        $quantity =$_POST['quantity'];
        $shoeSize =$_POST['shoeSize'];
            
        //Fetch customer ID
        $customerID=$_SESSION['customerID'];

        $cartID=null;

            //fetch the product details
            $fetchProduct = $connection-> prepare ("SELECT productName, productPrice FROM producttable WHERE productID = ?");
            $fetchProduct->bind_param("i",$productID);
            $fetchProduct->execute();
            $result = $fetchProduct->get_result();
            
            //check the product exists
            if ($result->num_rows>0) {
                $product = $result->fetch_assoc();

                $productName = $product['productName'];
                $productPrice = $product['productPrice'];

                //insert the product details into the cart table 
                $insertProducts = $connection-> prepare ("INSERT INTO cart (customerID, productID, quantity, productName, productPrice, shoeSize) 
                VALUES (?,?,?,?,?,?)");
                $insertProducts ->bind_param("iiissi", $customerID,$productID,$quantity,$productName,$productPrice,$shoeSize);
                $insertProducts->execute();

                echo "<script>alert('Product added to cart successfully.')</script>";
                header("Refresh:1; url=ProductsScreen.php");
            } else {
                echo "Could not add this product to your cart, please try again";
                header("Refresh:1; url=ProductsScreen.php");
            }
    } else {
        echo "Invalid product details";
    }

    //closing the database
    $connection->close();
?>