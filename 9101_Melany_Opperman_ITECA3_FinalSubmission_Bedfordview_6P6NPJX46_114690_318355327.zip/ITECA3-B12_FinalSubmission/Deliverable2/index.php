<?php
    if(isset($_POST['submit']))
    {
        $first_name = $_POST['first_name'];
        $last_name = $_POST['last_name'];
        $phone_number = $_POST['phone_number'];
        $email = $_POST['email'];
        $customer_password = $_POST['customer_password'];
        $delivery_address = $_POST['delivery_address'];

        //validating the email address
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            echo "This is an invalid email address!";
            exit;
        }
        //the database details were created in the account privileges in Xampp
        //Connecting to the database
        require_once('database_config.php');
        
        //creating the connection to the database
        $connection = mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD,DB_NAME);

        //checking if the connection works 
        if (!$connection)
        {
            die("Connection Failed!".mysqli_connect_error());
        }

        //check if the email has already been registered
        $sql = "SELECT * FROM customers WHERE email = '$email'";
        $rs = mysqli_query($connection, $sql);
        if (mysqli_num_rows($rs)>0) {
            echo "This email address has already been registered, try logging in!";
            exit;
        }
        //sending data put in form to the database
        $sql = "INSERT INTO customers (customerID, first_name, last_name, phone_number, email, customer_password, delivery_address) VALUES ('0', '$first_name', '$last_name', '$phone_number', '$email', '$customer_password','$delivery_address')";

        //saving the entries and checking with an if statement
        $rs = mysqli_query($connection, $sql);
        if ($rs && mysqli_affected_rows($connection)>0)
        {
            echo '<script>alert("Details Submitted Successfully!")</script>';
            header("Refresh:1; url=login.php");
        }
        else{
            echo '<script>alert("Error! Something has gone wrong and your details were not submitted. Try Again!")</script>';
            header("Refresh:1; url=index.php");
        }

        //closing the connection
        mysqli_close($connection);
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Elite Sneaks</title>
    <link rel="stylesheet" href="loginregstyle.css">

    <!--Validating the form with Javascript if the fields have not been entered-->
    <script type = "text/javascript">

        function validation()
        {
            if(document.register.first_name.value == ""){ 
                alert("Please enter your first name");
                document.register.first_name.focus();
                return false;
            }

            if(document.register.last_name.value == ""){ 
                alert("Please enter your last name");
                document.register.last_name.focus();
                return false;
            }

            if(document.register.phone_number.value == ""){ 
                alert("Please enter your phone number");
                document.register.phone_number.focus();
                return false;
            }

            if(document.register.email.value == ""){ 
                alert("Please enter your email");
                document.register.email.focus();
                return false;
            }
            if(document.register.customer_password.value == ""){ 
                alert("Please enter your password");
                document.register.customer_password.focus();
                return false;
            }
            return(true);
        }
    </script>
</head>
<body>
    <div class="menu">
        <ul class="navbar">
            <li><a href="index.php">Register</a></li>
            <li><a href="login.php">Login</a></li>
        </ul>
    </div>
        <!--the registration form that will connect to the registration.php-->
        <form class = "register-form" name = "registration" action = "index.php" method = "POST" onsubmit = "return(validation());">
        <div class="content">
            <!--Title of the Form: Registration-->
            <h1 class="main-header">R E G I S T R A T I O N</h1>
            <br><!--Input for the first name -->
            <label for = "message">First Name</label> 
            <input type = "text" id = "FirstName" name = "first_name" placeholder = "Enter your first name" required/>
            </br>
            <br> <!--Input for the last name-->
            <label for = "message">Last Name</label> 
            <input type = "text" id = "LastName" name = "last_name" placeholder = "Enter your last name"required/>
            </br>
            <br> <!--Input for the phone number-->
            <label for = "message">Phone Number</label> 
            <input type = "text" id = "PhoneNumber" name = "phone_number" placeholder = "Enter your phone number"required/>
            </br>
            <br> <!--Input for the email-->
            <label for = "message">Email</label> 
            <input type = "email" id = "UserEmail" name = "email" placeholder = "Enter your email address"required/>
            </br>
            <br> <!--Input for the Password-->
            <label for = "message">Password</label> 
            <input type = "password" id = "customer_password" name = "customer_password" placeholder = "Enter a password"required/>
            </br>
            <br>
            <label for = "message">Delivery Address</label> 
            <input type = "delivery_address" id = "delivery_address" name = "delivery_address" placeholder = "Enter your delivery address"required/>
            </br>
            <br>

            <!--Button for submitting the details to the database-->
            <input type = "submit" name = "submit" value = "Submit"/> </br>
            
        </div>
        </form>   
</body>
</html>