<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment</title>

<!-- styling in the header -->
<style>
@import url('https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300;1,400;1,500;1,600;1,700;1,800&display=swap');
/* styling for the header  */
header {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    background: none;
    padding: 20px 7%;
    display: flex;
    align-items: center;
    justify-content: space-between;
    z-index: 1000;
}

header .logo {
    width: 80px;
}

header .navbar ul{
    list-style: none;
}

header .navbar ul li {
    position: relative;
    float: left;
}

header .navbar ul li a {
    font-size: 20px;
    padding: 20px;
    color: white;
    display: block;
}

header .navbar ul li a:hover {
    text-decoration: underline;
}

header .navbar .fa-solid {
    color: #fff;
    padding: 3px;
}

header label  {
    font-size: 20px;
    color: #fff;
    cursor: pointer;
    display: none;
}
/* styling for the rest of the card details */
*{
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Poppins', sans-serif;
}

body{
    width: 100%;
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: #581830;
}

.PayContainer{
    width: 750px;
    height: 500px;
    border: 1px solid;
    background-color: white;
    display: flex;
    flex-direction: column;
    padding: 40px;
    justify-content:space-around;
}

.PayContainer h1{
    text-align: center;
}

.firstRow{
     display: flex;
}

.CardHolderName{
    width: 100%;
    margin-right: 40px;
}

.inputField{
    border: 1px solid #999;
}

.inputField input{
    width: 100%;
    border:none;
    outline: none;
    padding: 10px;
}

.selection{
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.selection select{
    padding: 10px 20px;
}

a{
    background-color: #581830;
    color: #fff;
    text-align: center;
    text-transform: uppercase;
    text-decoration: none;
    padding: 10px;
    font-size: 18px;
    transition: 0.5s;
}

a:hover{
    background-color: #581830;
}

.cards img{
    width: 100px;
}

</style>
</head>
<body>
    <!-- for the navigation header  -->
    <header style="background-color: #581830;">
        <?php
            include 'menu.php';
        ?>
    </header>

    <!-- the payment where you enter your card details  -->
    <div class="PayContainer">
        <h1>CONFIRM YOUR PAYMENT</h1>
        <div class="firstRow">
            <div class="CardHolderName">
                <h3>Cardholder Name</h3>
                <div class="inputField">
                    <input type="text">
                </div>
            </div>
            <div class="cvv">
                <h3>CVV</h3>
                <div class="inputField">
                    <input type="password">
                </div>
            </div>
        </div>

        <div class="secondRow">
            <div class="CardNumber">
                <h3>Card Number</h3>
                <div class="inputField">
                    <input type="text">
                </div>
            </div>
        </div>

        <div class="thirdRow">
            <h3>Card Expiry Date</h3>
            <div class="selection">
                <div class="date">
                    <select name="months" id="months">
                        <option value="Jan">Jan</option>
                        <option value="Feb">Feb</option>
                        <option value="Mar">Mar</option>
                        <option value="Apr">Apr</option>
                        <option value="May">May</option>
                        <option value="Jun">Jun</option>
                        <option value="Jul">Jul</option>
                        <option value="Aug">Aug</option>
                        <option value="Sep">Sep</option>
                        <option value="Oct">Oct</option>
                        <option value="Nov">Nov</option>
                        <option value="Dec">Dec</option>
                      </select>
                      <select name="years" id="years">
                        <option value="2020">2025</option>
                        <option value="2020">2024</option>
                        <option value="2020">2023</option>
                        <option value="2020">2022</option>
                        <option value="2020">2021</option>
                        <option value="2020">2020</option>
                        <option value="2019">2019</option>
                        <option value="2018">2018</option>
                        <option value="2017">2017</option>
                        <option value="2016">2016</option>
                        <option value="2015">2015</option>
                      </select>
                </div>
                <div class="cards">
                    <img src="mc.png" alt="">
                    <img src="vi.png" alt="">
                    <img src="pp.png" alt="">
                </div>
            </div>
        </div>
        <a href="">CONFIRM</a>
    </div>
</body>
</html>