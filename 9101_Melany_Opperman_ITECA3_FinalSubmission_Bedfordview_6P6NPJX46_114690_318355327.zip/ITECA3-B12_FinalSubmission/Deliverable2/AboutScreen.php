<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
        <header>
            <?php
                include 'menu.php';
            ?>
        </header> 
    <!--Container for story and goals with images -->
    <div class="Block">
        <!--header is the navigation bar with the logo that must be included on all pages--> 
        <div class="Content">
            <h1>ABOUT ELITE SNEAKS</h1>
            <br> 
            <h2>OUR STORY</h2>
            <p>Elite Sneaks is our company that sells luxurious, branded shoes. 
                Our physical store is based in Bedfordview. 
                The brands that are available at the moment are Nike, Louis Vuitton, Addidas Yeezy, and Gucci. 
            </p>
            <br>
            <h2>OUR GOAL</h2>
            <p>We are looking to expand out company to around South Africa with this online store.
                We wish to grow our business and make our name well-known so that we can open up 
                another physical store in Cape Town; and internationally in the further future.
            </p>
            <p>If you would like to know more about our store - Please feel free to contact us!</p>
            
            
        </div>
    </div>
    </class>
    
</body>
</html>