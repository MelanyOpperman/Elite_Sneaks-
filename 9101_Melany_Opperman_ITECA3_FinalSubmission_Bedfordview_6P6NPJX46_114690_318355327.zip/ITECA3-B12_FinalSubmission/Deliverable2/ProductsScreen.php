<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    

    <!--For the products-->
    <div class="product_hero" >
        <header style="background-color: #581830;">
            <?php
                include 'menu.php';
            ?>
        </header>

        <?php
        //the database details were created in the account privileges in Xampp
        //Connecting to the database
        require_once('database_config.php');
        
        //creating the connection to the database
        $connection = mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD,DB_NAME);
        
        //checking if the connection works 
        if (!$connection)
        {
            die("This Connection has Failed!".mysqli_connect_error());
        }

        //the query to fetch the product
        //prepared statements with parameterised queries to prevent sql injection
        $displayProducts = $connection-> prepare("SELECT productID, productImage, productName, productPrice FROM producttable");
        $displayProducts-> execute();
        $result = $displayProducts-> get_result();
        //loop for the query
        if ($result->num_rows>0) {
            while ($row = $result->fetch_assoc()) {
                echo '<div class="card">';
                echo '<img class="ProductImage" src="'. $row['productImage'] .'"alt="' . $row['productName'] .'">';
                echo '<div class="cardBody">';
                echo '<h5 class="cardTitle">'. $row['productName'] .'</h5>';
                echo '<p class="cardPrice" value=>R '. $row['productPrice'] .'</p>';
                echo '<a href="ViewProducts.php?productID=' . $row['productID'] .'" class="btnViewProd ">VIEW PRODUCT</a>';
                echo '</div>';
                echo '</div>';
            }
        } else {
            echo "No products available.";
        }

        //closing the database connection
        $connection->close();
        ?>
    </div>
    <footer>
        <?php
                include 'footer.php';
        ?>
    </footer>
</body>