<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact</title>
    <link rel="stylesheet" href="style.css">
    <script src="https://kit.fontawesome.com/9e70f8e206.js" crossorigin="anonymous"></script>

    <style>
        
    </style>
</head>
<body>
    <!--Social Media Buttons-->
    <div class="social">
        <a href="#">FACEBOOK <i class="fa-brands fa-facebook"></i></a>
        <a href="#">TWITTER <i class="fa-brands fa-twitter"></i></a>
        <a href="#">INSTAGRAM <i class="fa-brands fa-instagram"></i></a>    
        <a href="#">YOUTUBE <i class="fa-brands fa-youtube"></i></a>  
        <a href="#">EMAIL <i class="fa-solid fa-envelope"></i></a>       
    </div>

    <!--Header contains the navigation bar and logo like all other pages-->
    <header>
        <?php
            include 'menu.php';
        ?>
    </header>    
    <div class="container">
        <form>
            <h1>Contact Us</h1>
            <input type="text" id="FirstName" placeholder="First Name" required>
            <input type="text" id="LastName" placeholder="Last Name" required>
            <input type="email" id="email" placeholder="Email" required>
            <input type="text" id="cellNumber" placeholder="Cell Phone Number" required>
            
            <input type = "submit" class="submit" name = "submit" value = "Send"/> 
        </form>
    </div>
    <!-- footer of screen -->
    <footer>
            <?php
                    include 'footer.php';
            ?>
    </footer>
</body>
</html>