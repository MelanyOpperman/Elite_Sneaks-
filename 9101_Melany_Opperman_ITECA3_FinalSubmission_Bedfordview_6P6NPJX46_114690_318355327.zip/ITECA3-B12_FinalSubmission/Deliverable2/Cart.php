<?php
    //Connecting to the database
    require_once('database_config.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products</title>
    <link rel="stylesheet" href="style.css">

    <style>
        @import url('https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300;1,400;1,500;1,600;1,700;1,800&display=swap');

        *{
            background-color: #581830;
            
        }

        h2 {
            color: #fff;
            font-weight: bold;
            font-size: 1.8em;
            text-align: center;
            font-family: 'Open Sans', sans-serif;
        }

        p {
            color: #fff;
            font-size: 0.8em;
            text-align: center;
            font-family: 'Open Sans', sans-serif;
            margin-bottom: 20px;
        }
        .cartContainer {
            max-width: 600px;
            margin: 150px auto;
            padding: 20px;
            background-color: #581830;
            color: #fff;
        }
        .prodDetails {
            display: flex;
            flex-direction: column;
            justify-content: center;
            margin-left: 20px;
            flex: 1;
        }
        .cartItem {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
            border: 2px solid #fff;
            border-radius: 5px;
            padding: 10px;
        }

        .prodImg{
            width: 8em;
            max-width: 8em;
            height: 8em;
            object-fit: contain;
            margin-right: 20px;
        }

        .product-Name {
            font-weight: bold;
            margin: 5px 0;
        }

        .product-Quantity,
        .product-Price,
        .total-Price,
        .shoeSize {
            margin: 5px 0;
            font-size: 0.8em;
        }

        .Delete {
            align-self: flex-end;
            border: none;
            background-color: #fff;
            border: 2px solid #fff;
            border-radius: 5px;
            font-weight: 600;
            font-size: 15px;
            color: #5e5e5e;
            width: 100px;
            padding: 5px;
            margin-top: auto;
            transition: 0.3s;
            font-family: 'Open Sans', sans-serif;
        }

        .Checkout {
            border: none;
            background-color: #fff;
            border: 2px #fff ;
            border-radius: 5px;
            margin-top: 20px;
            font-weight: 600;
            font-size: 20px;
            color: #5e5e5e;
            width: 100px;
            padding: 5px;
            transition: 0.3s;
            align-self: center;
            font-family: 'Open Sans', sans-serif;
        }
    </style>

</head>
<body>
    <header style="background-color: #581830;">
        <?php
            include 'menu.php';
        ?>
    </header>
    <div class="cartContainer">
        <h2> YOUR CART </h2>

        <?php
            //creating the connection to the database
            $connection = mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD,DB_NAME);

            if(isset($_SESSION['customerID'])){
                //getting the cart products based on the customerID
                $customerID = $_SESSION['customerID'];

                //fetch cart products from customer
                $getProducts = $connection->prepare ("SELECT c.customerID, c.productID, c.quantity, c.productName, c.productPrice, c.shoeSize, p.productImage
                FROM cart c
                INNER JOIN producttable p ON c.productID=p.productID
                WHERE customerID = ?");
                $getProducts->bind_param("i",$customerID);
                $getProducts->execute();
                $result = $getProducts->get_result();

                if ($result->num_rows>0) {
                    echo '<div class="cartItem">';
                    while ($row = $result->fetch_assoc()) {
                        $productName = $row['productName'];
                        $productPrice = $row['productPrice'];
                        $quantity = $row['quantity'];
                        $shoeSize=$row['shoeSize'];
                        $productImage=$row['productImage'];
                        $productID=$row['productID'];

                        echo    '<div class="prodDetails">';
                        echo "<img class='prodImg' src='" . $productImage . "' >";
                        echo    '<p class="product-Name">' . $productName . '</p>';
                        echo    '<p class="product-Quantity">Quantity: ' . $quantity . '</p>';
                        echo    '<p class="product-Price">Price: R' . $productPrice . '</p>';
                        echo    '<p class="shoeSize">Shoe Size:' . $shoeSize . '</p>';
                        echo    "<center><a href='delete.php?productID=" .$productID ."'><input type = 'submit' class='Delete' name = 'Delete' value = 'Delete Item' /></a></center>";
                        echo    '</div>';
                    }
                    echo            '</div>';
                }else {
                    echo        '<p>Your cart is empty.</p>';
                }

            }else{
                echo            '<p>Please log in to view the cart.</p>>';
            }
            echo                '<center><a href="ProductsScreen.php" class="Checkout">Add</a></center>'; 
            echo                '<center><a href="Payment.php"><input type = "submit" class="Checkout" name = "Checkout" value = "Checkout"/></center>'; 

            //closing the database connection
            $connection->close();
        ?>
    </div>
</body>
</html>