<?php 
session_start(); 
?>

<script src="https://kit.fontawesome.com/9e70f8e206.js" crossorigin="anonymous"></script>

        <a href="Landing.php" class="logo">
            <img src="logo.png" class="logo">
        </a>
        <!-- for mobile view -->
        <!-- <input type="checkbox" id="mobileMenu">
        <label for="mobileMenu">MENU</label> -->

        <nav class="navbar">
            <ul>
                <li><a href="ProductsScreen.php">PRODUCTS</a> </li>
                <li><a href="AboutScreen.php">ABOUT</a> </li>
                <li><a href="ContactScreen.php">CONTACT US</a></li>
                <?php
                    if(isset($_SESSION['email'])){
                        echo '<li><a href="account.php">ACCOUNT</a> </li>';
                    }else{
                        echo '<li><a href="login.php">ACCOUNT</a> </li>';
                    }
                ?>
                <li>
                    <?php if(isset($_SESSION['customer']) && $_SESSION['customer']==true): ?>
                        <a href="Cart.php"><i class="fa-solid fa-cart-shopping"></i></a>
                    <?php endif; ?>
                </li>
            </ul>
        </nav>
        