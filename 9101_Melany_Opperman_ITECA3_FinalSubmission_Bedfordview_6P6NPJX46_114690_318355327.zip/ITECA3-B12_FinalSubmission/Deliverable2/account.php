<?php
    require_once('database_config.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
        <header>
            <?php
                include 'menu.php';
            ?>
        </header> 
    <!--Container for story and goals with images -->
    <div class="Block">
        <!--header is the navigation bar with the logo that must be included on all pages--> 
        <div class="Content">
            <?php
            
            //creating the connection to the database
            $connection = mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD,DB_NAME);
                echo '<h1>Profile:</h1><br>';
                
                $email=$_SESSION['email'];

                $sql = "SELECT * FROM customers WHERE email = '$email'";

                $res=mysqli_query($connection,$sql);

                $row = mysqli_fetch_assoc($res);

                //Store user info:
                $first_name=$row['first_name'];
                $last_name = $row['last_name'];
                $phone_number = $row['phone_number'];
                $email = $row['email'];

                //closing the connection
                mysqli_close($connection);

                //use the php command echo to display info in a block:
                //Displaying the user information in the container on the account page:
                echo "<p>Name: $first_name</p>";
                echo "<p>Surname: $last_name</p>";
                echo "<p>Phone Number: $phone_number</p>";
                echo "<p>Email Address: $email</p>";
            ?>
        </div>
    </div>
    </class>
    
</body>
</html>