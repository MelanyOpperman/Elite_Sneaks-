<?php 

        session_start();
        //the database details were created in the account privileges in Xampp
        //Connecting to the database
        require_once('database_config.php');
        
        //creating the connection to the database
        $connection = mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD,DB_NAME);

        // checking the customer is logged in
        if(!isset($_SESSION['customerID'])){
            
            echo '<script>alert("You need to be logged in to view this page")</script>';
            header("Refresh:1; url=login.html");
        } 

        //checking if the connection works 
        if (!$connection)
        {
            die("This Connection has Failed!".mysqli_connect_error());
        }
    

        if (isset($_GET['productID'])) {
            $productID = $_GET['productID'];

            //Fetch customer ID
            $customerID=$_SESSION['customerID'];

            $deleteProduct = $connection-> prepare("DELETE FROM cart WHERE cartID IN (SELECT cartID FROM cart WHERE customerID=?) 
            AND productID=?");
            $deleteProduct->bind_param("ii",$customerID,$productID);
            if ($deleteProduct->execute()) {
                echo '<script>alert("This product has been deleted.")</script>';
                 header("Refresh:1; url=Cart.php");
                 exit();
            } else {
                echo '<script>alert("Failed to delete product, please try again!")</script>';
                header("Refresh:1; url=Cart.php");
                exit();
            }
        } else {
            echo '<script>alert("Error, there was no product ID")</script>';
        }

    //closing the database
    $connection->close();
?>