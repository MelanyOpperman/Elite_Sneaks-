<?php
    require 'vendor/autoload.php';  //the vendor file when you download the composer file

    if(isset($_POST['submit']))
    {
        //database details
        $FirstName = $_POST['FirstName'];
        $LastName = $_POST['LastName'];
        $CellNumber = $_POST['CellNumber'];
        $Email = $_POST['Email'];

       
        //validating the email address
        if (!filter_var($Email, FILTER_VALIDATE_EMAIL)) {
            echo "This is an invalid email address!";
            exit;
        }
        //Connecting to the database
        require_once('database_config.php');
        
        //creating the connection to the database
        $connection = mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD,DB_NAME);

        //variables for the email
        $SMTP_SERVER= 'smtp.gmail.com';
        $SMTP_PORT= 587;
        $SMPT_USERNAME= 'elitesneaksSouthAfrica@gmail.com';
        $SMPT_PASSWORD= 'dvhpvjemunufrddk';

        //checking if the connection works 
        if (!$connection)
        {
            die("This Connection has Failed!".mysqli_connect_error());
        }

        //sending data put in form to the database
        $sql = "INSERT INTO contact (FirstName, LastName, CellNumber, Email) 
        VALUES ('$FirstName', '$LastName', '$CellNumber', '$Email')";

       

        //connecting the server with the variables created above
        $rs = mysqli_query($connection, $sql);

        if ($rs && mysqli_affected_rows($connection)>0){

            $Composer_mail = new \PHPMailer\PHPMailer\PHPMailer(true);

            try {

                $Composer_mail-> isSMTP();
                $Composer_mail-> Host = $SMTP_SERVER;
                $Composer_mail-> SMTPAuth=true;
                $Composer_mail-> Username=$SMPT_USERNAME;
                $Composer_mail-> Password=$SMPT_PASSWORD;
                $Composer_mail-> SMTPSecure='tls';
                $Composer_mail-> Port=$SMTP_PORT;

                //code for sending the email to the user 
                $Composer_mail-> setFrom($SMPT_USERNAME,'Elite Sneaks');
                $Composer_mail-> addAddress($email,$first_name);
                $Composer_mail-> isHTML(true);
                $Composer_mail-> Subject='Thank You for Contacting Elite Sneaks!';
                $Composer_mail-> Body =" <p>Hi $first_name,<p><br>
                                        <p>Thank you for your enquiry!</p></br>
                                        <p>Please let us know what your question is;</p>
                                        <p>or if you have any recommendations as well as comments you would like to send us.</p>
                                        <p>We will get back to you as soon as possible.</p>
                                        <p>The Elite Sneaks Team.</p>";
                $Composer_mail-> send();

                echo '<script>alert("Your message has been sent through to the team!")</script>';
                header("Refresh:3; url=Contact.html");
               
            }
            //catch is used for the error handling and will send a error message if it cannot be sent
            catch(Exception $e){
                echo "Error: Could not send email!";
                exit;
            }
        } else{
            echo "<script> alert('There was an error, Please try again!')</script>";
            header("Refresh:1; url=Contact.html");
            exit();
        }
        //closing the connection
        mysqli_close($connection);
    }
?>
