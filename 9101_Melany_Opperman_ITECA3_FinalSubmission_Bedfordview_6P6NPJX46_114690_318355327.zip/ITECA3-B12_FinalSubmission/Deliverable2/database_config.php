<?php
//Database details on pc
 define('DB_HOST','localhost');
define('DB_USER','Melany');
define('DB_PASSWORD','Melly@8891');
define('DB_NAME','elitesneaks'); 

//Testing on another computer
// define('DB_HOST','localhost');
// define('DB_USER','root');
// define('DB_PASSWORD','password');
// define('DB_NAME','elitesneaks');

//Database details for hosting
/* define('DB_HOST','');
define('DB_USER','');
define('DB_PASSWORD','');
define('DB_NAME',''); */
?>