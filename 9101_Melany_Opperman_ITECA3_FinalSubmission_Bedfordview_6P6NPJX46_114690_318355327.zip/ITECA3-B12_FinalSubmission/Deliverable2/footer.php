<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Footer</title>

    <style>
        footer {
            background-color: #fff;
            padding: 20px 0;
        }

        .foot-container {
            max-width: 960px;
            height: 18px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .footerLinks {
            color: #581830;
        }
        .socials a {
            color: #581830;
            margin-right: 10px;
            text-decoration: none;
        }

        p .Copy {
            color: #581830;
            align-items: center;
            font-size: 12px;
            padding-top: 50px;
            padding-left: 100px;
        }

        h6 {
            color: #581830;
            font-size: 18px;
        }
    </style>
</head>
<body>
    <!-- footer for the policies and the social links  -->
    <footer>
        <div class="foot-container">
            <div class="footerLinks">
                <h6>Policies</h6>
                <a href="cookiePolicy.html">Cookie Policy &nbsp</a> 
                <a href="privacy.html">Privacy Policy &nbsp</a> 
                <a href="termsConditions.html">Terms & Conditions</a>
            </div>
            <div class="socials">
                <h6>Social Media</h6>
                 <i class="fa-brands fa-facebook"></i></a>
                 <i class="fa-brands fa-twitter"></i></a>
                 <i class="fa-brands fa-instagram"></i></a>    
                 <i class="fa-brands fa-youtube"></i></a>  
                 <i class="fa-solid fa-envelope"></i></a>       
            
            </div>
            <h6 class="Copy">COPYRIGHT 2023 @ ELITE SNEAKS</h6>
        </div>
    </footer>
</body>
</html>