<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Elite Sneaks</title>
    <link rel="stylesheet" href="landingstyle.css">

    <script src="https://kit.fontawesome.com/9e70f8e206.js" crossorigin="anonymous"></script>
</head>
<body>
    <header>
        <?php
            include 'menu.php';
        ?>
    </header>
    <div class="container">

        <video autoplay loop muted plays-inline class="background-video">
            <source src="shoesvid1.mp4" type="video/mp4">
        </video> 
    
        <div id="LandingContent" class="content">
            <h1>Elite Sneaks</h1>
            <h2>Where Fashion Meets Footwear</h2>
            <a href="ProductsScreen.php">Shop Now</a> 
        </div>
    </div>
</body>
</html>